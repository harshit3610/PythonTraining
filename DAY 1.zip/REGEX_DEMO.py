import re
"""
some test strings to understand methods of re
this can be anything
"""
s1="123"
s2="HARSHIT"
s3="345123Harshit"
s4="123Harshit@"
#first let's see match in action
#match only looks at the start. Nowhere else

pattern=re.compile(r"123[A-Za-z].*")

#gonna do a one line if-else like it's no big deal
#and gonna break it down for visibility just 
# because I can!!!
print ("Match found") if re.match(pattern,s3)\
     else print("NO MATCH")

#search looks for exact pattern throughout the string. 
print("GOT IT:",re.search(pattern,s3))

# long_string="""
# This is a long string.
# Very long indeed.
# Now we'll se how many times I see This here
# Every This has to be found!
# """
# pattern=re.compile(r"This")
# for result in re.findall(pattern,long_string):
#     print(result)

# """
# Got them all, didn't we?
# But it's no fun this way!
# Need their positions too
# """

# for result in re.finditer(pattern,long_string):
#     print(result)

# """
# see, much better!
# """
