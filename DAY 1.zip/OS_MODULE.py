import os

from datetime import datetime
# print(dir(os))

# print(os.getcwd())
# os.chdir("D:\Projects\Python Training")
# print(os.getcwd())
# print(os.listdir())
#os.mkdir("DEMO")
#os.makedirs("TEST/SUBLEVEL") #NESTED directory kind of similar to mkdir -p
#os.rmdir("../DEMO")
###############################################################
# print(os.stat('Training\Subprocess_Demo.py'))
# ans=os.stat('Training\Subprocess_Demo.py').st_mtime
# #let's get that modified time in human readable form
# print(datetime.fromtimestamp(ans))

################################################################
"""
Let's go for a walk

"""

# for path,name,files in os.walk(os.getcwd()):
#     print(path,name,files,sep="\n")
#     print() #a blank line to separate
###################################################################

print(os.environ.get("HOMEPATH"))

#WORKING WITH PATH

filepath=os.path.join(os.getcwd(),"EXAMPLE_PATH.txt")
print(filepath)

#need not be existing path
print(os.path.basename(os.getcwd())) #last part
print(os.path.dirname(os.getcwd())) #parent directory
print(os.path.split(os.getcwd()))

print(os.path.exists(os.getcwd()))
print(os.path.isfile(os.path.join(os.getcwd(),"OS_MODULE.py"))) 
"""
#messy. Could be written in a neater way, wanna try?
"""
focus=os.path.join(os.getcwd(),"OS_MODULE.py")
print(os.path.splitext(focus))
########################################3
