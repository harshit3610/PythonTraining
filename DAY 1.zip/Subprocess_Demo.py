from subprocess import PIPE,Popen,run,DEVNULL

# """
# run was added in python 3.5. Easiest way to run commands.
# However, it waits for execution of process before other statements
# """

# run('dir',shell=True) #need shell =True on windows

# run('ping -n 1 8.8.8.8',shell=True) #even this will work
# ###################################################################
# #We can capture output also

# result=run('dir',shell=True,capture_output=True)

# #captured output is byte string
# print(result.stdout.decode(),result.stderr,sep="**\n")


# #can also get correctly formatted string by using text argument

# result=run('dir',shell=True,text=True,capture_output=True)
# print(result.stdout)
#######################################################################

"""
Let's redirect output to a file
"""

f=open('CAPTURED_OUTPUT',"w")

result=run('dir',shell=True,text=True,stdout=f)
f.close()

###########################################################

"""
status codes can be checked
"""

# #let's try a wrong command to see error

# result=run('dis',shell=True,capture_output=True)
# print(result.returncode)#this will be one

# print(result.stderr) #here is the exact error

###########################################################
"""
Python didn't catch error. Let's make python observe
"""

#result=run('dis',shell=True,capture_output=True,check=True) #python got it

#run('dis',shell=True,capture_output=True,stderr=DEVNULL) #cannot use together

# run('dis',shell=True,stderr=DEVNULL) #See no error now

###############################################################################

"""

Let's share output between processes
"""
#Lot is going on here!!!!!
p1=Popen('dir',shell=True,stdout=PIPE)
run('findstr "example"',shell=True,stdin=p1.stdout)

#####################################################################


#obj=Popen(['ping','8.8.8.8'],stdout=PIPE,stderr=PIPE)
#sp.call(['powershell.exe','ls'],shell=True)


